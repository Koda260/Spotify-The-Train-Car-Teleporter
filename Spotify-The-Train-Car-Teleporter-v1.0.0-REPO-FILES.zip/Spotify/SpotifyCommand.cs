using System;
using UI.Console;

namespace SpotifyTrainCarTeleporter
{
    [ConsoleCommand("/spotify", "Spot waybilled train cars at their assigned destinations.")]
    public sealed class SpotifyCommand : IConsoleCommand
    {
        public string Execute(string[] components)
        {
            try
            {
                if (components == null || components.Length <= 1)
                {
                    return SpotifyEngine.SpotAll();
                }

                string arg = components[1] ?? string.Empty;

                if (arg.Equals("check", StringComparison.OrdinalIgnoreCase))
                {
                    return SpotifyEngine.Check();
                }

                if (arg.Equals("help", StringComparison.OrdinalIgnoreCase) ||
                    arg.Equals("?", StringComparison.OrdinalIgnoreCase))
                {
                    return SpotifyEngine.HelpText;
                }

                return "Spotify: unknown option '" + arg + "'.\n" + SpotifyEngine.HelpText;
            }
            catch (Exception ex)
            {
                return "Spotify failed: " + ex.GetBaseException().Message;
            }
        }
    }
}
