using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

namespace SpotifyTrainCarTeleporter
{
    internal static class ReflectionUtil
    {
        private const BindingFlags AnyInstance =
            BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase;

        private const BindingFlags AnyStatic =
            BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase;

        public static Type FindType(params string[] names)
        {
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                foreach (string name in names)
                {
                    if (string.IsNullOrWhiteSpace(name))
                        continue;

                    try
                    {
                        Type exact = assembly.GetType(name, false);
                        if (exact != null)
                            return exact;
                    }
                    catch
                    {
                    }
                }
            }

            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try
                {
                    types = assembly.GetTypes();
                }
                catch (ReflectionTypeLoadException ex)
                {
                    types = ex.Types;
                }
                catch
                {
                    continue;
                }

                if (types == null)
                    continue;

                foreach (Type type in types)
                {
                    if (type == null)
                        continue;

                    foreach (string name in names)
                    {
                        if (string.IsNullOrWhiteSpace(name))
                            continue;

                        if (string.Equals(type.Name, name, StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(type.FullName, name, StringComparison.OrdinalIgnoreCase))
                        {
                            return type;
                        }
                    }
                }
            }

            return null;
        }

        public static object GetMemberValue(object instance, params string[] names)
        {
            if (instance == null)
                return null;

            Type type = instance.GetType();

            foreach (string name in names)
            {
                if (string.IsNullOrWhiteSpace(name))
                    continue;

                try
                {
                    PropertyInfo property = type.GetProperty(name, AnyInstance);
                    if (property != null && property.GetIndexParameters().Length == 0)
                        return property.GetValue(instance, null);
                }
                catch
                {
                }

                try
                {
                    FieldInfo field = type.GetField(name, AnyInstance);
                    if (field != null)
                        return field.GetValue(instance);
                }
                catch
                {
                }
            }

            return null;
        }

        public static object GetStaticMemberValue(Type type, params string[] names)
        {
            if (type == null)
                return null;

            foreach (string name in names)
            {
                if (string.IsNullOrWhiteSpace(name))
                    continue;

                try
                {
                    PropertyInfo property = type.GetProperty(name, AnyStatic);
                    if (property != null && property.GetIndexParameters().Length == 0)
                        return property.GetValue(null, null);
                }
                catch
                {
                }

                try
                {
                    FieldInfo field = type.GetField(name, AnyStatic);
                    if (field != null)
                        return field.GetValue(null);
                }
                catch
                {
                }
            }

            return null;
        }

        public static MethodInfo FindInstanceMethod(Type type, string name, int parameterCount)
        {
            if (type == null)
                return null;

            foreach (MethodInfo method in type.GetMethods(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (string.Equals(method.Name, name, StringComparison.Ordinal) &&
                    method.GetParameters().Length == parameterCount)
                {
                    return method;
                }
            }

            return null;
        }

        public static MethodInfo FindInstanceMethod(Type type, string name, Type parameterType)
        {
            if (type == null)
                return null;

            foreach (MethodInfo method in type.GetMethods(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                ParameterInfo[] parameters = method.GetParameters();
                if (string.Equals(method.Name, name, StringComparison.Ordinal) &&
                    parameters.Length == 1 &&
                    parameters[0].ParameterType == parameterType)
                {
                    return method;
                }
            }

            return null;
        }

        public static IEnumerable<object> EnumerateValues(object value)
        {
            if (value == null)
                yield break;

            IDictionary dictionary = value as IDictionary;
            if (dictionary != null)
            {
                foreach (object item in dictionary.Values)
                    yield return item;
                yield break;
            }

            IEnumerable enumerable = value as IEnumerable;
            if (enumerable == null || value is string)
            {
                yield return value;
                yield break;
            }

            foreach (object item in enumerable)
            {
                if (item == null)
                    continue;

                // Support dictionaries / KeyValuePair collections without taking a compile-time dependency.
                object pairValue = GetMemberValue(item, "Value");
                if (pairValue != null && item.GetType().Name.StartsWith("KeyValuePair", StringComparison.Ordinal))
                    yield return pairValue;
                else
                    yield return item;
            }
        }

        public static bool ReadBool(object instance, bool fallback, params string[] names)
        {
            object value = GetMemberValue(instance, names);
            if (value == null)
                return fallback;

            try
            {
                return Convert.ToBoolean(value);
            }
            catch
            {
                return fallback;
            }
        }

        public static string ReadString(object instance, params string[] names)
        {
            object value = GetMemberValue(instance, names);
            return value == null ? null : Convert.ToString(value);
        }

        public static string IdentifierOf(object value)
        {
            if (value == null)
                return null;

            string id = ReadString(value, "Identifier", "identifier", "Id", "id");
            if (!string.IsNullOrWhiteSpace(id))
                return id;

            return value.ToString();
        }

        public static string CarLabel(object car)
        {
            if (car == null)
                return "<null car>";

            string id = ReadString(car, "Id", "ID", "Identifier", "identifier", "CarId", "carId");
            if (!string.IsNullOrWhiteSpace(id))
                return id;

            string reportingMark = ReadString(car, "ReportingMark", "reportingMark", "RoadName", "roadName");
            string number = ReadString(car, "Number", "number", "RoadNumber", "roadNumber");
            string combined = ((reportingMark ?? string.Empty) + " " + (number ?? string.Empty)).Trim();
            if (!string.IsNullOrWhiteSpace(combined))
                return combined;

            string text = car.ToString();
            return string.IsNullOrWhiteSpace(text) ? car.GetType().Name : text;
        }
    }
}
