Place LOCAL build references in this folder:

Assembly-CSharp.dll
FUSE.dll
UnityEngine.dll
UnityEngine.CoreModule.dll
UnityEngine.UI.dll
Newtonsoft.Json.dll

These DLLs are intentionally ignored by Git and should not be published in the repository.
