using Railloader;

namespace SpotifyTrainCarTeleporter
{
    /// <summary>
    /// FUSE 1.0.3 hosts this through its built-in Railloader compatibility shim.
    /// A separate Railloader installation is not required.
    /// </summary>
    public sealed class SpotifyPlugin : PluginBase
    {
        private readonly IModdingContext _context;

        public SpotifyPlugin(IModdingContext context, IModDefinition definition)
        {
            _context = context;
        }

        public override void OnEnable()
        {
            if (_context != null)
            {
                _context.RegisterConsoleCommand(new SpotifyCommand());
            }
        }
    }
}
