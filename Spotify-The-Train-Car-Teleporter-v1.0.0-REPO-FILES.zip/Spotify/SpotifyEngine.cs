using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace SpotifyTrainCarTeleporter
{
    internal static class SpotifyEngine
    {
        public const string HelpText =
            "Spotify - The Train Car Teleporter v1.0.0\n" +
            "  /spotify check  - inspect cars without moving anything\n" +
            "  /spotify        - spot all cars with open waybills using Railroader's native Sweep";

        private sealed class CarPlan
        {
            public object Car;
            public string Label;
            public string DestinationId;
            public string SkipReason;
        }

        public static string Check()
        {
            RuntimeSurface runtime;
            string error;
            if (!TryGetRuntime(out runtime, out error))
                return "Spotify check failed: " + error;

            List<CarPlan> plans = BuildPlans(runtime);

            int ready = plans.Count(p => string.IsNullOrEmpty(p.SkipReason));
            int skipped = plans.Count - ready;

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Spotify CHECK - no cars were moved.");
            sb.AppendLine("Cars scanned: " + plans.Count + " | ready: " + ready + " | skipped: " + skipped);

            foreach (CarPlan plan in plans)
            {
                if (!string.IsNullOrEmpty(plan.SkipReason))
                {
                    sb.AppendLine("SKIP  " + plan.Label + " - " + plan.SkipReason);
                }
                else
                {
                    string current = CurrentPositionId(runtime, plan.Car);
                    string location = string.IsNullOrWhiteSpace(current) ? "unspotted / en route" : current;
                    sb.AppendLine("READY " + plan.Label + " - " + location + " -> " + plan.DestinationId);
                }
            }

            return sb.ToString().TrimEnd();
        }

        public static string SpotAll()
        {
            RuntimeSurface runtime;
            string error;
            if (!TryGetRuntime(out runtime, out error))
                return "Spotify failed: " + error;

            if (!IsHost())
                return "Spotify: spotting cars is host-only.";

            List<CarPlan> plans = BuildPlans(runtime);
            List<CarPlan> candidates = plans.Where(p => string.IsNullOrEmpty(p.SkipReason)).ToList();

            if (candidates.Count == 0)
            {
                return BuildNoCandidatesResult(plans);
            }

            string nativeResult;
            try
            {
                object result = runtime.SweepAll.Invoke(runtime.OpsController, new object[] { "*" });
                nativeResult = result == null ? string.Empty : result.ToString();
            }
            catch (Exception ex)
            {
                return "Spotify: Railroader Sweep failed: " + ex.GetBaseException().Message;
            }

            int spotted = 0;
            foreach (CarPlan plan in candidates)
            {
                string actual = CurrentPositionId(runtime, plan.Car);
                if (IdentifiersEqual(actual, plan.DestinationId))
                {
                    spotted++;
                }
                else
                {
                    plan.SkipReason =
                        "Railroader could not place it at '" + plan.DestinationId +
                        "' (destination unavailable, invalid, or no open track space)";
                }
            }

            int skipped = plans.Count(p => !string.IsNullOrEmpty(p.SkipReason));

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Spotify finished.");
            sb.AppendLine("Cars scanned: " + plans.Count + " | spotted: " + spotted + " | skipped: " + skipped);

            if (!string.IsNullOrWhiteSpace(nativeResult))
                sb.AppendLine("Railroader Sweep: " + nativeResult);

            foreach (CarPlan plan in plans)
            {
                if (!string.IsNullOrEmpty(plan.SkipReason))
                {
                    sb.AppendLine("SKIP  " + plan.Label + " - " + plan.SkipReason);
                }
                else
                {
                    sb.AppendLine("SPOT  " + plan.Label + " -> " + plan.DestinationId);
                }
            }

            return sb.ToString().TrimEnd();
        }

        private static string BuildNoCandidatesResult(List<CarPlan> plans)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Spotify: there are no open-waybill cars to spot.");
            foreach (CarPlan plan in plans)
            {
                if (!string.IsNullOrEmpty(plan.SkipReason))
                    sb.AppendLine("SKIP  " + plan.Label + " - " + plan.SkipReason);
            }
            return sb.ToString().TrimEnd();
        }

        private static List<CarPlan> BuildPlans(RuntimeSurface runtime)
        {
            List<CarPlan> result = new List<CarPlan>();

            foreach (object car in GetCars(runtime))
            {
                CarPlan plan = new CarPlan
                {
                    Car = car,
                    Label = ReflectionUtil.CarLabel(car)
                };

                object waybill = ReflectionUtil.GetMemberValue(car, "Waybill", "waybill");
                if (waybill == null)
                {
                    plan.SkipReason = "no active waybill";
                    result.Add(plan);
                    continue;
                }

                bool completed = ReflectionUtil.ReadBool(
                    waybill,
                    false,
                    "Completed",
                    "completed",
                    "IsCompleted",
                    "isCompleted");

                if (completed)
                {
                    plan.SkipReason = "waybill already completed";
                    result.Add(plan);
                    continue;
                }

                object destination = ReflectionUtil.GetMemberValue(waybill, "Destination", "destination");
                plan.DestinationId = ReflectionUtil.IdentifierOf(destination);

                if (string.IsNullOrWhiteSpace(plan.DestinationId))
                {
                    plan.SkipReason = "open waybill has no resolvable destination";
                    result.Add(plan);
                    continue;
                }

                result.Add(plan);
            }

            return result
                .OrderBy(p => p.DestinationId ?? "~", StringComparer.OrdinalIgnoreCase)
                .ThenBy(p => p.Label, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private static IEnumerable<object> GetCars(RuntimeSurface runtime)
        {
            object carsValue = ReflectionUtil.GetMemberValue(
                runtime.TrainController,
                "Cars",
                "cars",
                "_cars");

            foreach (object car in ReflectionUtil.EnumerateValues(carsValue))
            {
                if (car != null)
                    yield return car;
            }
        }

        private static string CurrentPositionId(RuntimeSurface runtime, object car)
        {
            if (runtime.PositionForCar == null || car == null)
                return null;

            try
            {
                object position = runtime.PositionForCar.Invoke(runtime.OpsController, new object[] { car });
                return ReflectionUtil.IdentifierOf(position);
            }
            catch
            {
                return null;
            }
        }

        private static bool IdentifiersEqual(string actual, string expected)
        {
            if (string.IsNullOrWhiteSpace(actual) || string.IsNullOrWhiteSpace(expected))
                return false;

            return string.Equals(
                actual.Trim(),
                expected.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsHost()
        {
            Type stateManagerType = ReflectionUtil.FindType("Game.State.StateManager", "StateManager");
            if (stateManagerType == null)
                return true;

            object value = ReflectionUtil.GetStaticMemberValue(stateManagerType, "IsHost", "isHost");
            if (value == null)
                return true;

            try
            {
                return Convert.ToBoolean(value);
            }
            catch
            {
                return true;
            }
        }

        private sealed class RuntimeSurface
        {
            public object OpsController;
            public object TrainController;
            public MethodInfo SweepAll;
            public MethodInfo PositionForCar;
        }

        private static bool TryGetRuntime(out RuntimeSurface runtime, out string error)
        {
            runtime = null;
            error = null;

            Type opsType = ReflectionUtil.FindType("Model.Ops.OpsController", "OpsController");
            if (opsType == null)
            {
                error = "Model.Ops.OpsController was not found.";
                return false;
            }

            object ops = ReflectionUtil.GetStaticMemberValue(opsType, "Shared", "shared", "Instance", "instance");
            if (ops == null)
            {
                error = "OpsController.Shared is not available. Load a save first.";
                return false;
            }

            MethodInfo sweepAll = ReflectionUtil.FindInstanceMethod(opsType, "Sweep", typeof(string));
            if (sweepAll == null)
            {
                error = "OpsController.Sweep(string) was not found.";
                return false;
            }

            Type trainType = ReflectionUtil.FindType("TrainController");
            if (trainType == null)
            {
                error = "TrainController was not found.";
                return false;
            }

            object train = ReflectionUtil.GetStaticMemberValue(trainType, "Shared", "shared", "Instance", "instance");
            if (train == null)
            {
                error = "TrainController.Shared is not available. Load a save first.";
                return false;
            }

            MethodInfo positionForCar = null;
            foreach (MethodInfo method in opsType.GetMethods(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (string.Equals(method.Name, "PositionForCar", StringComparison.Ordinal) &&
                    method.GetParameters().Length == 1)
                {
                    positionForCar = method;
                    break;
                }
            }

            runtime = new RuntimeSurface
            {
                OpsController = ops,
                TrainController = train,
                SweepAll = sweepAll,
                PositionForCar = positionForCar
            };

            return true;
        }
    }
}
